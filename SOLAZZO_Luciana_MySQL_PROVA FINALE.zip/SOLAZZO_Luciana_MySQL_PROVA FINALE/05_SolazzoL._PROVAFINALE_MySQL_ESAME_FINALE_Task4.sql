-- Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:  
-- N.B. per il popolamento far riferimento al file 04_PROVA FINALE_CreazioneTabellePopolamento.sql

/* 1) Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK (una query per tabella implementata).*/

/* METODO 1 (verifichiamo che i valori siano univoci; ho creato la query per tutte le tabelle, partendo da sales che ha una chiave composita)
in questo primo metodo andiamo a verificare che i valori delle colonne che pensiamo possano essere PK non abbiano duplicati, quindi ottenere una tabella vuota è esattamente il tipo di risposta che cerchiamo */

SELECT 
	SalesOrderNumber
    , SalesOrderLineNumber -- la tabella Sales ha una chiave composita
    , COUNT(*)
FROM Sales
GROUP BY 
	SalesOrderNumber
    , SalesOrderLineNumber
HAVING COUNT(*) > 1
	;

SELECT 
	ProductKey
    , COUNT(*)
FROM Product
GROUP BY 
	ProductKey
HAVING COUNT(*) > 1
	;

SELECT
	CategoryID
    , COUNT(*)
FROM Category
GROUP BY 
	CategoryID
HAVING COUNT(*) > 1
	;

SELECT
	RegionID
    , COUNT(*)
FROM Region
GROUP BY 
	RegionID
HAVING COUNT(*) > 1
	;

SELECT
	CountryID
    , COUNT(*)
FROM Country
GROUP BY 
	CountryID
HAVING COUNT(*) > 1
	;

-- METODO 2 ( verifichiamo in un'unica query tutte le pk dello schema)
SELECT 
	CONSTRAINT_NAME
    , TABLE_SCHEMA
    , TABLE_NAME
    , COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE CONSTRAINT_NAME = 'Primary' 
	AND TABLE_SCHEMA = 'ToysGroup'
    ; 

/* 2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni 
dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT 
	S.SalesOrderNumber				AS DocumentCode
	, S.OrderDate					AS 'Date'
    , P.ProductName					AS Product
    , Ca.CategoryName				AS Category
    , R.RegionName					AS Region
    , Co.CountryName				AS Country
    , (DATEDIFF(CURRENT_DATE, s.Orderdate) > 180) AS '+180days'
FROM 
	Sales AS S
INNER JOIN 
	Product AS P
ON S.Productkey = P.Productkey
INNER JOIN 
	Category AS Ca
ON P.CategoryID = Ca.CategoryID
INNER JOIN 
	Country AS Co
ON S.RegionID = Co.RegionID
INNER JOIN 
	Region AS R
ON Co.RegionID = r.RegionID
ORDER BY S.OrderDate ASC;


/* 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto. */

SELECT 
	s.ProductKey
    , SUM(s.OrderQuantity) 		AS TotalQuantity
FROM 
	Sales  						AS S
WHERE YEAR(s.OrderDate) = (SELECT 							-- questa Subqyery cerca l'anno più recente nella tabella sales
								MAX(YEAR(OrderDate)) 
                                FROM Sales)
GROUP BY s.ProductKey
HAVING SUM(s.OrderQuantity) > (SELECT 						-- Filtra i risultati per mostrare solo i prodotti con una quantità totale ordinata maggiore della media annuale
								 AVG(OrderQuantity)
								 FROM Sales
WHERE YEAR(OrderDate) = (SELECT 							-- questa Subqyery limita il calcolo della media all'anno più recente
								MAX(YEAR(OrderDate)) 
                                FROM Sales)
);

-- 4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
SELECT 
    S.Productkey					AS PrKey
    , P.ProductName					AS Product
	, YEAR(S.OrderDate)				AS 'Year'
    , SUM(S.SalesAmount)			AS TotalSalesperY
FROM 
	Sales							AS  S
INNER JOIN
	Product							AS P
ON S.ProductKey = P.ProductKey
WHERE s.OrderQuantity > 0  -- where condition per Filtrare solo i prodotti effettivamente venduti
GROUP BY S.ProductKey, YEAR(S.OrderDate)
ORDER BY Year, S.Productkey
	;

-- 5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT 
	YEAR(s.OrderDate)		AS SalesDate
	, co.CountryName 		AS Country
	, SUM(s.SalesAmount) 	AS TotRevenue
FROM 
	Sales 					AS s
INNER JOIN Country 			AS co 
ON s.RegionID = co.RegionID
GROUP BY YEAR(s.OrderDate), co.CountryName
ORDER BY 
	YEAR(s.OrderDate) ASC
	, co.CountryName
    , TotRevenue DESC
	;    
    
-- 6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT 
	Ca.CategoryName			AS Categoria
    , SUM(S.SalesAmount)	AS TotalSales
FROM 
	Product					AS P
INNER JOIN Sales			AS S
ON P.Productkey = S.ProductKey
INNER JOIN 
	Category				AS Ca
ON P.CategoryID = Ca.CategoryID
GROUP BY Categoria
ORDER BY TotalSales DESC
LIMIT 1; -- per vedere la categoria che ha venduto di più, dopo aver posto le altre condizioni basta limitare la ricerca 

-- 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- 1° CASO
SELECT 
	s.ProductKey  		AS 'ProductCode'
    , p.ProductName 	AS 'productname'
FROM 
	Sales AS s 
LEFT JOIN Product p 
ON s.Productkey = p.Productkey
WHERE s.ProductKey IS NULL
	;

-- 2° CASO
SELECT 
    p.ProductKey  			AS 'ProductCode'
    , p.ProductName 		AS 'productname'
FROM 
    Product 				AS p
WHERE 
    p.ProductKey NOT IN (SELECT 
							s.ProductKey 
							FROM Sales AS S)
	;

/* 8) Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
(codice prodotto, nome prodotto, nome categoria) */

CREATE VIEW VW_LuSo_InfoProduct AS 
SELECT
	p.ProductKey			AS 'Code'
    , p.ProductName			AS 'Name'
    , ca.CategoryName			AS Category
FROM 
	product					AS p
LEFT OUTER JOIN 
	Category				AS ca
ON p.categoryID = ca.categoryID
	;	

-- 9) Creare una vista per le informazioni geografiche 

CREATE VIEW VW_LuSo_InfoGeography AS 
SELECT
	CountryID				AS GeoKey
    , CountryName			AS State
    , RegionName			AS Area
FROM 
	Country 				AS co
LEFT OUTER JOIN 
	Region					AS r
ON r.regionID = co.regionID
	;	


